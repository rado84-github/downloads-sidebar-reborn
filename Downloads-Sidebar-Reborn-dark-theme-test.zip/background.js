const sidebarDownloadsPanel = {
  panel: browser.extension.getURL("sidebar/panel.html")
};

let sidebarOpen = false;

browser.browserAction.onClicked.addListener(() => {
  if (sidebarOpen) {
    browser.sidebarAction.close();
  } else {
    browser.sidebarAction.setPanel(sidebarDownloadsPanel);
    browser.sidebarAction.open();
  }
  sidebarOpen = !sidebarOpen;
});

browser.sidebarAction.onDetached.addListener(() => {
  sidebarOpen = false;
});
